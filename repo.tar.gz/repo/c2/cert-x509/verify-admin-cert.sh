#!/bin/bash

openssl verify -CAfile ca.pem admin.pem