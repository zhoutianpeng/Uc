#!/bin/bash

openssl x509 -in admin.pem -text -noout