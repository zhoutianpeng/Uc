#!/bin/bash

openssl x509 -in ca.pem -text -noout