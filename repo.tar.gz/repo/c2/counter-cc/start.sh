#!/bin/bash
gradle run --args='--id counter-cc:0 --peer.address 127.0.0.1:7052'
