#!/bin/bash
gradle run
