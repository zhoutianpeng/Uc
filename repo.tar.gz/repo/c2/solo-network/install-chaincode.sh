#!/bin/bash

peer chaincode install -n counter-cc -v 0 -l java -p /home/user/repo/c2/counter-cc
