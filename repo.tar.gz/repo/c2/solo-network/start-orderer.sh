#!/bin/bash

ORDERER_GENERAL_GENESISPROFILE=SampleInsecureSolo \
ORDERER_FILELEDGER_LOCATION=./data/orderer \
orderer 
