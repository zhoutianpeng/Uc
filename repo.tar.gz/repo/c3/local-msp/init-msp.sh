#!/bin/bash

cryptogen generate --config=crypto-config.yaml