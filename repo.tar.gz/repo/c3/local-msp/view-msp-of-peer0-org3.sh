#!/bin/bash

tree crypto-config/peerOrganizations/org3.example.com/peers/peer0.org3.example.com/msp