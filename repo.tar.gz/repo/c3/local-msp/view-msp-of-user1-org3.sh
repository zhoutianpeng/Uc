#!/bin/bash

tree crypto-config/peerOrganizations/org3.example.com/users/User1@org3.example.com/msp