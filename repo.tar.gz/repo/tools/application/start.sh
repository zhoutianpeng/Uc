#!/bin/bash
gradle run 
