#!/bin/bash
gradle run --args='--id wizcc:0 --peer.address 127.0.0.1:7052'
